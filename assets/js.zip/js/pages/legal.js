export const initLegal = () => {};
