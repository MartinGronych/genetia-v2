export const initResearch = () => {};
